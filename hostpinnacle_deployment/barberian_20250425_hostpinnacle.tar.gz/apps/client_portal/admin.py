from django.contrib import admin
# No models to register for the client_portal app yet
